## R2S 基于 Linux LTS 内核的 OpenWrt 19.07 固件

### 发布地址：
https://github.com/QiuSimons/R2S_OP_SSRP/releases

### 注意事项：
1.登陆IP：192.168.50.1 密码：无

2.LAN和WAN做了互换处理

3.不要使用脚本升级，推荐使用R2SFlasher（请用1.0-4以上的版本，茄子），从其他固件升级过来请务必不要保留设置。

4.不要自行添加守护脚本，自带了守护了

5.SSRP使用姿势： ①添加你要的订阅链接 ②再在最后加一行空行 ③右下角点一下保存并应用 ④更新所有订阅服务器节点

### 版本信息：
Kernel版本：5.4.y（当日最新）

OpenWrt版本：19.07（当日最新）

### 特性及功能：
1.内核O3编译

2.OpenWRT Ofast编译

3.内置两款主题，包含SSRP，openclash，adguardhome，微信推送，网易云解锁，SQM，SmartDNS，网络唤醒，DDNS，迅雷快鸟，UPNP，FullCone，流量分载（offload），BBR（默认开启）
